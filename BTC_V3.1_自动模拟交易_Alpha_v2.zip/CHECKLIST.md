# V3.1 Alpha v2 启动检查

- [ ] Node.js 20+
- [ ] npm install
- [ ] `.env` 已创建
- [ ] DEMO=true
- [ ] 使用 OKX Demo API Key
- [ ] API Key 没有提现权限
- [ ] AUTO_TRADE=false 先观察
- [ ] /health 返回 ok=true
- [ ] /api/status 有 BTC/OI/Funding
- [ ] 数据稳定后再开启 Demo 自动交易
- [ ] 每笔交易同时核对 OKX Demo 订单、成交、TP/SL 状态
