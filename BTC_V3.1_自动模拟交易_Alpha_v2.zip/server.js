
import express from "express";
import crypto from "crypto";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const PORT = Number(process.env.PORT || 8787);
const BASE = "https://www.okx.com";
const INST = "BTC-USDT-SWAP";
const DEMO = String(process.env.DEMO ?? "true").toLowerCase() === "true";

const CFG = {
  capital: Number(process.env.CAPITAL || 10000),
  budgetPct: Number(process.env.BUDGET_PCT || 30),
  riskPct: Number(process.env.RISK_PCT || 1.0),
  maxLeverage: Number(process.env.MAX_LEVERAGE || 8),
  maxDailyLossPct: Number(process.env.MAX_DAILY_LOSS_PCT || 3),
  maxTradesPerDay: Number(process.env.MAX_TRADES_PER_DAY || 5),
};

const state = {
  autoTrade: String(process.env.AUTO_TRADE || "false").toLowerCase() === "true",
  price: null, oi: null, prevOi: null, funding: null, book: null,
  candles: {}, signal: null, position: null,
  lastCycle: 0, lastError: null, trades: loadTrades(),
  daily: { date: dayKey(), pnl: 0, trades: 0 },
};

function dayKey(){ return new Date().toISOString().slice(0,10); }
function resetDailyIfNeeded(){
  const d = dayKey();
  if(state.daily.date !== d) state.daily = {date:d,pnl:0,trades:0};
}
function logPath(){ return path.join(__dirname, "trades.json"); }
function loadTrades(){
  try { return JSON.parse(fs.readFileSync(logPath(),"utf8")); } catch { return []; }
}
function saveTrades(){ fs.writeFileSync(logPath(), JSON.stringify(state.trades.slice(-1000), null, 2)); }
function n(v){ const x=Number(v); return Number.isFinite(x)?x:null; }
function clamp(x,a,b){ return Math.max(a,Math.min(b,x)); }
function avg(a){ return a.length ? a.reduce((x,y)=>x+y,0)/a.length : null; }
function sma(a,p){ return a.length<p?null:avg(a.slice(-p)); }
function ema(a,p){
  if(a.length<p) return null;
  const k=2/(p+1); let e=avg(a.slice(0,p));
  for(let i=p;i<a.length;i++) e=a[i]*k+e*(1-k);
  return e;
}
function sd(a,p){
  if(a.length<p) return null;
  const x=a.slice(-p), m=avg(x);
  return Math.sqrt(avg(x.map(v=>(v-m)**2)));
}
function rsi(a,p=14){
  if(a.length<p+1) return null;
  let g=0,l=0;
  for(let i=a.length-p;i<a.length;i++){ const d=a[i]-a[i-1]; if(d>0)g+=d; else l-=d; }
  return l===0?100:100-100/(1+g/l);
}
function atr(c,p=14){
  if(c.length<p+1)return null;
  const tr=[];
  for(let i=1;i<c.length;i++){
    const x=c[i],q=c[i-1];
    tr.push(Math.max(x.h-x.l,Math.abs(x.h-q.c),Math.abs(x.l-q.c)));
  }
  return sma(tr,p);
}
function adx(c,p=14){
  if(c.length<p*2+1)return null;
  const tr=[],plus=[],minus=[];
  for(let i=1;i<c.length;i++){
    const x=c[i],q=c[i-1];
    tr.push(Math.max(x.h-x.l,Math.abs(x.h-q.c),Math.abs(x.l-q.c)));
    const up=x.h-q.h, down=q.l-x.l;
    plus.push(up>down&&up>0?up:0); minus.push(down>up&&down>0?down:0);
  }
  const dx=[];
  for(let i=p;i<tr.length;i++){
    const t=avg(tr.slice(i-p+1,i+1))*p;
    const po=avg(plus.slice(i-p+1,i+1))*p;
    const mi=avg(minus.slice(i-p+1,i+1))*p;
    const pi=100*po/(t||1), mn=100*mi/(t||1);
    dx.push(100*Math.abs(pi-mn)/(pi+mn||1));
  }
  return sma(dx,p);
}
function macd(a){
  if(a.length<35)return null;
  const fast=ema(a,12), slow=ema(a,26);
  if(fast==null||slow==null)return null;
  const mac=fast-slow;
  return {mac};
}
function tfSignal(c){
  if(!c?.length)return null;
  const cl=c.map(x=>x.c), last=cl.at(-1), e20=ema(cl,20), e50=ema(cl,50);
  const rr=rsi(cl), aa=atr(c), ad=adx(c), mm=sma(cl,20), ss=sd(cl,20);
  const md=macd(cl);
  let score=0;
  score += last>e20?12:-12;
  score += e20>e50?14:-14;
  score += rr>55?10:rr<45?-10:0;
  score += (md && md.mac>0)?8:(md && md.mac<0?-8:0);
  score += ad && ad>22 ? (last>e20?10:-10) : 0;
  score += ss && last>mm+2*ss?6:(ss&&last<mm-2*ss?-6:0);
  return {score, dir:score>15?"LONG":score<-15?"SHORT":"NEUTRAL", last,e20,e50,rsi:rr,atr:aa,adx:ad,macd:md?.mac??null};
}
function bookBias(book){
  if(!book)return 0;
  const bid=(book.bids||[]).reduce((s,x)=>s+Number(x[1]),0);
  const ask=(book.asks||[]).reduce((s,x)=>s+Number(x[1]),0);
  return (bid-ask)/(bid+ask||1);
}

async function okx(pathname, opts={}){
  const url = BASE + pathname;
  const method = opts.method || "GET";
  const body = opts.body ? JSON.stringify(opts.body) : "";
  const ts = new Date().toISOString();
  const headers = {"Content-Type":"application/json"};
  if(process.env.OKX_API_KEY){
    const prehash = ts + method + pathname + body;
    const sign = crypto.createHmac("sha256", process.env.OKX_SECRET_KEY || "")
      .update(prehash).digest("base64");
    headers["OK-ACCESS-KEY"]=process.env.OKX_API_KEY;
    headers["OK-ACCESS-SIGN"]=sign;
    headers["OK-ACCESS-TIMESTAMP"]=ts;
    headers["OK-ACCESS-PASSPHRASE"]=process.env.OKX_PASSPHRASE || "";
    if(DEMO) headers["x-simulated-trading"]="1";
  }
  const r=await fetch(url,{method,headers,body:body||undefined});
  const j=await r.json();
  if(!r.ok || (j.code && j.code!=="0")) throw new Error(JSON.stringify(j));
  return j;
}

async function getCandles(bar){
  const j=await okx(`/api/v5/market/candles?instId=${INST}&bar=${bar}&limit=300`);
  return j.data.map(x=>({t:+x[0],o:+x[1],h:+x[2],l:+x[3],c:+x[4],v:+x[5]})).reverse();
}
async function refreshData(){
  const bars=["1m","5m","15m","30m","1H"];
  const [ticker,oi,fr,book,...cs]=await Promise.all([
    okx(`/api/v5/market/ticker?instId=${INST}`),
    okx(`/api/v5/public/open-interest?instType=SWAP&instId=${INST}`),
    okx(`/api/v5/public/funding-rate?instId=${INST}`),
    okx(`/api/v5/market/books?instId=${INST}&sz=20`),
    ...bars.map(getCandles)
  ]);
  state.price=Number(ticker.data[0].last);
  state.prevOi=state.oi;
  state.oi=Number(oi.data[0].oi);
  state.funding=Number(fr.data[0].fundingRate);
  state.book=book.data[0];
  bars.forEach((b,i)=>state.candles[b]=cs[i]);
}

function buildSignal(){
  const t={};
  for(const b of ["1m","5m","15m","30m","1H"]) t[b]=tfSignal(state.candles[b]);
  if(Object.values(t).some(x=>!x)) return null;
  const w={ "1m":.08,"5m":.14,"15m":.25,"30m":.27,"1H":.26 };
  const tech=Object.entries(w).reduce((s,[k,v])=>s+t[k].score*v,0);
  const oiDelta=state.oi&&state.prevOi?(state.oi-state.prevOi)/state.prevOi:0;
  const ob=bookBias(state.book);
  let deriv=clamp(ob*15, -15, 15);
  if(state.funding>0.0001) deriv-=4;
  if(state.funding<-0.0001) deriv+=4;
  if(Math.abs(oiDelta)>0.0005) deriv += tech>0 ? 4 : -4;
  let score=50+tech*.55+deriv*.55;
  score=clamp(score,0,100);

  const major=t["15m"].dir===t["30m"].dir && t["30m"].dir===t["1H"].dir;
  const shortConfirm=(t["1m"].dir===t["5m"].dir) || t["1m"].dir==="NEUTRAL";
  const regime=t["1H"].adx>25 ? (t["1H"].e20>t["1H"].e50?"TREND_UP":"TREND_DOWN") : "RANGE";
  let direction = score>=50 ? "LONG" : "SHORT";
  if(!major || !shortConfirm || regime==="RANGE" || Math.abs(score-50)<12) direction="WAIT";
  const confidence=clamp(Math.abs(score-50)*2,0,100);
  return {time:Date.now(),direction,score,confidence,major,shortConfirm,regime,tech,deriv,oiDelta,ob,t};
}

function makePlan(sig){
  if(!sig || sig.direction==="WAIT" || sig.confidence<45 || !state.price) return null;
  const cap=CFG.capital, riskMoney=cap*CFG.riskPct/100, budget=cap*CFG.budgetPct/100;
  const ref=sig.t["5m"].atr || state.price*.004;
  const stopDist=Math.max(ref*1.25,state.price*.0035);
  const rr1=1.5, rr2=2.2;
  const entry=state.price;
  const sl=sig.direction==="LONG"?entry-stopDist:entry+stopDist;
  const tp1=sig.direction==="LONG"?entry+stopDist*rr1:entry-stopDist*rr1;
  const tp2=sig.direction==="LONG"?entry+stopDist*rr2:entry-stopDist*rr2;
  const rawNotional=riskMoney/(stopDist/entry);
  const notional=Math.min(budget,rawNotional);
  const lev=clamp(notional/Math.max(riskMoney,1),1,CFG.maxLeverage);
  return {direction:sig.direction,entry,sl,tp1,tp2,riskMoney,notional,lev,margin:notional/lev};
}

async function getPositions(){
  if(!process.env.OKX_API_KEY) return [];
  const j=await okx(`/api/v5/account/positions?instType=SWAP&instId=${INST}`);
  return (j.data||[]).filter(p=>Number(p.pos||0)!==0);
}
async function getInstrument(){
  const j=await okx(`/api/v5/public/instruments?instType=SWAP&instId=${INST}`);
  return j.data?.[0];
}
async function placeDemoOrder(plan){
  if(!DEMO) throw new Error("Safety stop: DEMO must be true.");
  if(!process.env.OKX_API_KEY) throw new Error("Missing OKX demo API credentials.");
  resetDailyIfNeeded();
  if(state.daily.pnl <= -CFG.capital*CFG.maxDailyLossPct/100) throw new Error("Daily loss limit reached.");
  if(state.daily.trades >= CFG.maxTradesPerDay) throw new Error("Daily trade limit reached.");
  const ins=await getInstrument();
  const ctVal=Number(ins?.ctVal||0.01);
  const sz=Math.max(1,Math.floor(plan.notional/(plan.entry*ctVal)));
  const body={
    instId:INST, tdMode:"isolated", side:plan.direction==="LONG"?"buy":"sell",
    ordType:"market", sz:String(sz), posSide:"net",
    attachAlgoOrds:[{
      attachAlgoClOrdId:`v31${Date.now()}`.slice(0,32),
      tpTriggerPx:String(plan.tp1), tpOrdPx:"-1", tpTriggerPxType:"mark",
      slTriggerPx:String(plan.sl), slOrdPx:"-1", slTriggerPxType:"mark"
    }]
  };
  const result=await okx("/api/v5/trade/order",{method:"POST",body});
  const trade={id:result.data?.[0]?.ordId||String(Date.now()),time:Date.now(),side:plan.direction,entry:plan.entry,sl:plan.sl,tp1:plan.tp1,tp2:plan.tp2,notional:plan.notional,status:"OPEN",demo:true};
  state.trades.push(trade); saveTrades(); state.daily.trades++;
  return trade;
}

async function cycle(){
  resetDailyIfNeeded();
  try{
    await refreshData();
    state.signal=buildSignal();
    state.lastCycle=Date.now();
    state.lastError=null;
    const plan=makePlan(state.signal);
    if(state.autoTrade && process.env.AUTO_TRADE === "true" && process.env.OKX_API_KEY && process.env.OKX_SECRET_KEY && process.env.OKX_PASSPHRASE && plan && !state.position){
      state.position=await placeDemoOrder(plan);
    }
    if(state.position){
      const p=state.price, pos=state.position;
      const hit = pos.side==="LONG" ? (p<=pos.sl || p>=pos.tp1) : (p>=pos.sl || p<=pos.tp1);
      if(hit){
        // Exchange-attached TP/SL is authoritative; this is only a local state check.
        pos.lastCheck=p;
        if((pos.side==="LONG"&&p>=pos.tp1)||(pos.side==="SHORT"&&p<=pos.tp1)) pos.status="TP1_TOUCHED";
        if((pos.side==="LONG"&&p<=pos.sl)||(pos.side==="SHORT"&&p>=pos.sl)) pos.status="SL_TOUCHED";
        saveTrades();
      }
      const live=await getPositions().catch(()=>[]);
      if(live.length===0 && pos.status!=="OPEN"){
        state.position=null;
      }
    }
  }catch(e){ state.lastError=String(e?.message||e); }
}

app.get("/api/status",(req,res)=>{
  resetDailyIfNeeded();
  res.json({
    demo:DEMO,autoTrade:state.autoTrade,price:state.price,oi:state.oi,prevOi:state.prevOi,
    funding:state.funding,signal:state.signal,position:state.position,lastCycle:state.lastCycle,
    lastError:state.lastError,daily:state.daily,config:CFG,trades:state.trades.slice(-50)
  });
});
app.post("/api/settings",(req,res)=>{
  if(typeof req.body?.autoTrade==="boolean") state.autoTrade=req.body.autoTrade;
  res.json({ok:true,autoTrade:state.autoTrade,demo:DEMO});
});
app.post("/api/refresh",async(req,res)=>{ await cycle(); res.json({ok:true}); });
app.get("/health",(req,res)=>res.json({ok:true,demo:DEMO,autoTrade:state.autoTrade,lastCycle:state.lastCycle,lastError:state.lastError}));
app.get("/",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));

setInterval(cycle, 12000);
cycle();
app.listen(PORT,()=>console.log(`BTC V3.1 Demo server on :${PORT} | DEMO=${DEMO}`));
