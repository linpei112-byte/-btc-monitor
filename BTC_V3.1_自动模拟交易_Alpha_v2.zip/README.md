# BTC V3.1 自动模拟交易 Alpha v2

目标：先在 OKX Demo 模拟盘中自动分析、自动模拟开仓、自动附带止损/止盈、记录每笔交易，并用真实市场样本验证策略。

## 已搭建
- 1m / 5m / 15m / 30m / 1H
- EMA / RSI / MACD / ATR / ADX
- OI / Funding / 盘口偏置
- 多周期方向融合、震荡过滤
- 动态风险金额、策略资金池、仓位、SL、TP1/TP2
- OKX Demo Market Order
- 下单附带 TP/SL
- 交易日志
- 每日亏损/交易次数限制
- iPhone 浏览器控制台
- DEMO 安全锁
- API Key 只在服务器环境变量

## 尚未宣称完成
ETF/链上/完整清算/完整主动成交、新闻/宏观实时融合、严格 Walk-forward 回测、长期稳定性验证、实盘交易。这些需要继续开发和验证。

## 安全
- `DEMO=true` 必须保持。
- `AUTO_TRADE=false` 默认关闭。
- 不要把 API Key / Secret / Passphrase 发到聊天。
- API Key 只使用 OKX Demo Key。
- 禁止提现权限。
- 先运行观察，再开启自动模拟交易。

## 启动
需要 Node.js 20+：
1. `npm install`
2. 复制 `.env.example` 为 `.env`
3. 填 OKX Demo API Key / Secret / Passphrase
4. `npm start`
5. 打开 `http://localhost:8787`
6. 先检查 `http://localhost:8787/health`

确认数据正常后，才考虑将 `AUTO_TRADE=true` 用于 Demo 自动模拟交易。

## 后续
WebSocket、严格历史回测、Walk-forward/out-of-sample、手续费/滑点、清算/主动成交、ETF/新闻/宏观、持仓恢复、防重复下单、TP1/TP2 分批止盈。
