BTC Safari 自动盯盘（第一版）

最快使用方式：
1. 把 index.html 上传到 GitHub 仓库。
2. 在 GitHub 仓库 Settings -> Pages 中选择 Deploy from branch。
3. 选择 main / root，保存。
4. GitHub 会生成一个 https://...github.io/... 的网址。
5. 用 iPhone Safari 打开网址即可；Safari -> 分享 -> 添加到主屏幕，可像 App 一样使用。

本版本直接读取 OKX 公共市场数据，不需要 API Key。
方向判断目前是规则引擎，不是真正的 LLM。下一版可以接 AI 接口，并增加砸盘瞬间检测、历史窗口、报警和多交易所交叉验证。
